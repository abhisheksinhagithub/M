document.write(`
<nav class="nav">
  <div class="wrap">
    <a href="index.html" class="brand"><svg class="mf-mark" viewBox="0 0 39 32" width="32" height="26" fill="none" aria-hidden="true"><path d="M6 16 C14 16 14 7 21 7 L28 7" stroke="#17B8A6" stroke-width="2.8" stroke-linecap="round"/><path d="M6 16 L28 16" stroke="#6C5CE7" stroke-width="2.8" stroke-linecap="round"/><path d="M6 16 C14 16 14 25 21 25 L28 25" stroke="#FF6B4A" stroke-width="2.8" stroke-linecap="round"/><circle cx="33" cy="7" r="2.2" fill="#17B8A6"/><circle cx="33" cy="16" r="2.2" fill="#6C5CE7"/><circle cx="33" cy="25" r="2.2" fill="#FF6B4A"/><circle cx="5.6" cy="16" r="3" fill="#0B1220"/></svg><span class="brand-text">Multiflow<small class="brand-sub">One Platform. Multiple Possibilities.</small></span></a>
    <ul class="nav-links">
      <li><a href="index.html">Home</a></li>
      <li><a href="products.html">Products</a></li>
      <li><a href="solutions.html">Solutions</a></li>
      <li><a href="pricing.html">Pricing</a></li>
      <li><a href="blog.html">Resources</a></li>
      <li><a href="company.html">Company</a></li>
      <li><a href="contact.html">Contact</a></li>
    </ul>
    <div class="nav-cta">
      <a href="login.html" class="btn btn--ghost btn--sm">Login</a>
      <a href="signup.html" class="btn btn--primary btn--sm">Get Started</a>
      <button class="nav-toggle" aria-label="Menu"><span></span><span></span><span></span></button>
    </div>
  </div>
</nav>
<script>
  (function(){
    var page = location.pathname.split("/").pop() || "index.html";
    document.querySelectorAll(".nav-links a").forEach(function(a){
      if (a.getAttribute("href") === page) a.style.color = "var(--text-dark)";
    });
  })();
</script>
`);

function writeMultiflowFooter() {
  document.write(`
<footer class="footer">
  <div class="wrap">
    <div class="footer-brand">
      <a href="index.html" class="brand" style="color:var(--text-on-ink);"><svg class="mf-mark" viewBox="0 0 39 32" width="32" height="26" fill="none" aria-hidden="true"><path d="M6 16 C14 16 14 7 21 7 L28 7" stroke="#17B8A6" stroke-width="2.8" stroke-linecap="round"/><path d="M6 16 L28 16" stroke="#6C5CE7" stroke-width="2.8" stroke-linecap="round"/><path d="M6 16 C14 16 14 25 21 25 L28 25" stroke="#FF6B4A" stroke-width="2.8" stroke-linecap="round"/><circle cx="33" cy="7" r="2.2" fill="#17B8A6"/><circle cx="33" cy="16" r="2.2" fill="#6C5CE7"/><circle cx="33" cy="25" r="2.2" fill="#FF6B4A"/><circle cx="5.6" cy="16" r="3" fill="#FFFFFF"/></svg><span class="brand-text">Multiflow<small class="brand-sub">One Platform. Multiple Possibilities.</small></span></a>
      <p>WhatsApp marketing and automation for businesses across India — with SMS, RCS, Voice and Email joining soon.</p>
    </div>
    <div><h4>Products</h4><ul>
      <li><a href="products.html#whatsapp">WhatsApp API</a></li>
      <li><a href="products.html#automation">Marketing Automation</a></li>
      <li><a href="products.html#sms">Bulk SMS &amp; Voice <small>· soon</small></a></li>
      <li><a href="products.html#rcs">RCS Messaging <small>· soon</small></a></li>
      <li><a href="products.html#email">Email Marketing <small>· soon</small></a></li>
    </ul></div>
    <div><h4>Solutions</h4><ul>
      <li><a href="solutions.html">Automation</a></li>
      <li><a href="solutions.html#industries">Industries</a></li>
      <li><a href="reseller.html">Reseller / Agency</a></li>
      <li><a href="pricing.html">Pricing</a></li>
    </ul></div>
    <div><h4>Company</h4><ul>
      <li><a href="company.html">About Multiflow</a></li>
      <li><a href="company.html#why">Why us</a></li>
      <li><a href="blog.html">Blog</a></li>
      <li><a href="contact.html">Contact</a></li>
    </ul></div>
    <div><h4>Legal</h4><ul>
      <li><a href="legal.html#privacy">Privacy Policy</a></li>
      <li><a href="legal.html#terms">Terms &amp; Conditions</a></li>
      <li><a href="legal.html#refund">Refund Policy</a></li>
    </ul></div>
    <div><h4>Contact</h4><ul>
      <li><a href="mailto:info@multiflow.co.in">info@multiflow.co.in</a></li>
      <li><a href="tel:+919999999999">+91 99999 99999</a></li>
      <li><a href="https://wa.me/919999999999">WhatsApp us</a></li>
    </ul></div>
  </div>
  <div class="footer-bottom">
    <span>© <span class="year"></span> Multiflow. All rights reserved.</span>
    <span>multiflow.co.in</span>
  </div>
</footer>

<a href="https://wa.me/919999999999?text=Hi%20Multiflow%2C%20I%27d%20like%20to%20know%20more" class="wa-float" aria-label="Chat on WhatsApp">
  <svg width="28" height="28" viewBox="0 0 24 24" fill="#fff"><path d="M12 2C6.48 2 2 6.48 2 12c0 1.85.5 3.58 1.36 5.07L2 22l5.06-1.33A9.94 9.94 0 0 0 12 22c5.52 0 10-4.48 10-10S17.52 2 12 2zm0 18c-1.6 0-3.1-.44-4.38-1.2l-.31-.19-3.13.82.84-3.04-.2-.32A7.94 7.94 0 0 1 4 12c0-4.41 3.59-8 8-8s8 3.59 8 8-3.59 8-8 8zm4.4-5.6c-.24-.12-1.42-.7-1.64-.78-.22-.08-.38-.12-.54.12-.16.24-.62.78-.76.94-.14.16-.28.18-.52.06-.24-.12-1.02-.38-1.94-1.2-.72-.64-1.2-1.43-1.34-1.67-.14-.24-.02-.37.1-.49.11-.11.24-.28.36-.42.12-.14.16-.24.24-.4.08-.16.04-.3-.02-.42-.06-.12-.54-1.3-.74-1.78-.2-.47-.4-.4-.54-.41h-.46c-.16 0-.42.06-.64.3-.22.24-.84.82-.84 2s.86 2.32.98 2.48c.12.16 1.7 2.6 4.12 3.64.58.25 1.03.4 1.38.51.58.18 1.11.16 1.53.1.47-.07 1.42-.58 1.62-1.14.2-.56.2-1.04.14-1.14-.06-.1-.22-.16-.46-.28z"/></svg>
</a>
<script src="assets/script.js"><\/script>
`);
}

/* ---------- Auth modal: Login/Signup pop over the current page with a blurred backdrop ---------- */
(function () {
  if (window.self !== window.top) return; // never nest a modal inside the modal iframe

  const css = document.createElement("style");
  css.textContent = [
    ".auth-pop-overlay{ position:fixed; inset:0; z-index:4000; display:none; align-items:center; justify-content:center; padding:18px;",
    "  background:rgba(8,13,25,0.45); backdrop-filter:blur(9px) saturate(1.1); -webkit-backdrop-filter:blur(9px) saturate(1.1); }",
    ".auth-pop-overlay.open{ display:flex; animation:authFade .22s ease; }",
    "@keyframes authFade{ from{ opacity:0; } to{ opacity:1; } }",
    ".auth-pop-frame{ position:relative; width:min(680px,96vw); height:min(780px,94vh); animation:authRise .25s ease; }",
    "@keyframes authRise{ from{ transform:translateY(16px); opacity:0; } to{ transform:none; opacity:1; } }",
    ".auth-pop-frame iframe{ width:100%; height:100%; border:0; background:transparent; }",
    ".auth-pop-close{ position:absolute; top:-4px; right:-4px; z-index:2; width:34px; height:34px; border-radius:50%; border:0;",
    "  background:#fff; color:#10151F; font-size:15px; font-weight:700; cursor:pointer; box-shadow:0 6px 20px rgba(0,0,0,0.35); }",
    ".auth-pop-close:hover{ background:#EEF1F7; }",
    "body.auth-pop-lock{ overflow:hidden; }",
  ].join("\n");
  document.head.appendChild(css);

  const overlay = document.createElement("div");
  overlay.className = "auth-pop-overlay";
  overlay.innerHTML = '<div class="auth-pop-frame"><button class="auth-pop-close" aria-label="Close">✕</button><iframe allowtransparency="true" title="Multiflow account"></iframe></div>';
  if (document.body) document.body.appendChild(overlay);
  else document.addEventListener("DOMContentLoaded", function () { document.body.appendChild(overlay); });

  function authFrame() { return overlay.querySelector("iframe"); }
  function openAuth(url) {
    authFrame().src = url + (url.indexOf("?") > -1 ? "&" : "?") + "embed=1";
    overlay.classList.add("open");
    document.body.classList.add("auth-pop-lock");
  }
  function closeAuth() {
    overlay.classList.remove("open");
    document.body.classList.remove("auth-pop-lock");
    authFrame().src = "about:blank";
  }

  document.addEventListener("click", function (e) {
    const a = e.target.closest ? e.target.closest("a[href]") : null;
    if (a) {
      const href = a.getAttribute("href");
      if (/^(login|signup)\.html(\?|#|$)/.test(href)) { e.preventDefault(); openAuth(href); return; }
    }
    if (e.target === overlay || (e.target.classList && e.target.classList.contains("auth-pop-close"))) closeAuth();
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") closeAuth(); });
  window.addEventListener("message", function (e) { if (e.data === "mf-close-auth") closeAuth(); });
})();
