/* ============================================================
   MULTIFLOW — Supabase client & data layer
   Replace the CONFIG values below with your own project's
   URL and anon key (Supabase dashboard → Project Settings → API).
   ============================================================ */

const SUPABASE_CONFIG = {
  url: "https://YOUR-PROJECT-REF.supabase.co",
  anonKey: "YOUR-ANON-PUBLIC-KEY",
};

const sb = window.supabase.createClient(SUPABASE_CONFIG.url, SUPABASE_CONFIG.anonKey);

// ---------- Auth ----------

async function signUpBusiness(form) {
  const { data: authData, error: authError } = await sb.auth.signUp({
    email: form.email,
    password: form.password,
    options: { data: { account_name: form.accountName, phone: form.phone } },
  });
  if (authError) return { error: authError.message };

  // Profile row is created automatically by the DB trigger.
  // Now create the business row linked to this new user.
  const { error: bizError } = await sb.from("businesses").insert({
    profile_id: authData.user.id,
    account_type: form.accountType || "individual",
    business_name: form.businessName,
    business_type: form.businessType,
    category: form.category,
    gstin: form.gstin || null,
    pan: form.pan,
    website: form.website || null,
    address: form.address,
    city: form.city,
    state: form.state,
    pincode: form.pincode,
    wa_number: form.waNumber,
    display_name: form.displayName,
    fb_bm_id: form.fbBmId || null,
    volume: form.volume,
    use_case: form.useCase,
    channels: form.channels,
    plan: form.plan,
    status: "pending_verification",
  });
  if (bizError) return { error: bizError.message };

  return { data: authData };
}

async function signIn(email, password) {
  const { data, error } = await sb.auth.signInWithPassword({ email, password });
  if (error) return { error: error.message };

  const { data: profile, error: profileError } = await sb
    .from("profiles").select("*").eq("id", data.user.id).single();
  if (profileError) return { error: profileError.message };

  return { data: { user: data.user, profile } };
}

async function signOutUser() {
  await sb.auth.signOut();
}

async function getCurrentProfile() {
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return null;
  const { data: profile } = await sb.from("profiles").select("*").eq("id", user.id).single();
  return profile ? { ...profile, email: user.email } : null;
}

async function requireProfileRole(role) {
  const profile = await getCurrentProfile();
  if (!profile || profile.role !== role) {
    window.location.href = "login.html";
    return null;
  }
  return profile;
}

// ---------- Business data (customer side) ----------

async function getMyBusiness() {
  const { data: { user } } = await sb.auth.getUser();
  if (!user) return null;
  const { data, error } = await sb.from("businesses").select("*").eq("profile_id", user.id).single();
  if (error) return null;
  return data;
}

// ---------- Business data (admin side) ----------

async function listPendingBusinesses() {
  const { data, error } = await sb
    .from("businesses").select("*, profiles(account_name, phone)")
    .eq("status", "pending_verification")
    .order("created_at", { ascending: true });
  return error ? [] : data;
}

async function listAllBusinesses() {
  const { data, error } = await sb
    .from("businesses").select("*, profiles(account_name, phone)")
    .order("created_at", { ascending: false });
  return error ? [] : data;
}

async function setBusinessStatus(businessId, status) {
  const { data: { user } } = await sb.auth.getUser();
  const { error } = await sb.from("businesses").update({
    status, reviewed_at: new Date().toISOString(), reviewed_by: user.id,
  }).eq("id", businessId);
  return !error;
}

// ---------- Reseller sub-accounts (only used when account_type = 'reseller') ----------

async function listMyClients(businessId) {
  const { data, error } = await sb
    .from("reseller_clients").select("*")
    .eq("reseller_business_id", businessId)
    .order("created_at", { ascending: false });
  return error ? [] : data;
}

async function addClient(businessId, client) {
  const { error } = await sb.from("reseller_clients").insert({
    reseller_business_id: businessId,
    client_name: client.name,
    client_email: client.email,
    client_phone: client.phone,
    plan: client.plan || "starter",
  });
  return !error;
}

async function setClientStatus(clientId, status) {
  const { error } = await sb.from("reseller_clients").update({ status }).eq("id", clientId);
  return !error;
}

// ---------- Shared UI utilities (used by dashboard.html / admin.html) ----------

const CHANNELS = [
  { key: "whatsapp", label: "WhatsApp", color: "#17B8A6" },
  { key: "sms", label: "SMS", color: "#6C5CE7" },
  { key: "rcs", label: "RCS", color: "#8F87F0" },
  { key: "voice", label: "Voice", color: "#FF6B4A" },
  { key: "email", label: "Email", color: "#4FD1C5" },
];

const PLANS = [
  { id: "starter", name: "Starter", price: "₹2,999/mo", desc: "Up to 10,000 msgs · WhatsApp + SMS" },
  { id: "growth", name: "Growth", price: "₹8,999/mo", desc: "Up to 75,000 msgs · All 5 channels" },
  { id: "enterprise", name: "Enterprise", price: "Custom", desc: "Unlimited · Dedicated support" },
];

function channelMeta(key) {
  return CHANNELS.find((c) => c.key === key) || CHANNELS[0];
}

function statusPillClass(status) {
  const map = {
    approved: "good", Approved: "good", Completed: "good", Operational: "good", Paid: "good",
    pending_verification: "warn", Pending: "warn", Scheduled: "warn", Degraded: "warn",
    rejected: "bad", Rejected: "bad",
    Running: "brand", Draft: "neutral",
  };
  return map[status] || "neutral";
}
function statusLabel(status) {
  const map = { approved: "Approved", pending_verification: "Pending verification", rejected: "Rejected" };
  return map[status] || status;
}
