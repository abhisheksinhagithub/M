// Nav toggle
const navToggle = document.querySelector('.nav-toggle');
const navLinks = document.querySelector('.nav-links');
if (navToggle) {
  navToggle.addEventListener('click', () => {
    navLinks.classList.toggle('open');
    navToggle.classList.toggle('open');
  });
  navLinks.querySelectorAll('a').forEach(a => a.addEventListener('click', () => {
    navLinks.classList.remove('open');
    navToggle.classList.remove('open');
  }));
}

// FAQ accordion
document.querySelectorAll('.faq-item').forEach(item => {
  const btn = item.querySelector('.faq-q');
  const ans = item.querySelector('.faq-a');
  btn.addEventListener('click', () => {
    const isOpen = item.classList.contains('open');
    document.querySelectorAll('.faq-item.open').forEach(o => {
      o.classList.remove('open');
      o.querySelector('.faq-a').style.maxHeight = null;
    });
    if (!isOpen) {
      item.classList.add('open');
      ans.style.maxHeight = ans.scrollHeight + 'px';
    }
  });
});

// Scroll reveal
const revealEls = document.querySelectorAll('.reveal');
if ('IntersectionObserver' in window && revealEls.length) {
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('in');
        io.unobserve(e.target);
      }
    });
  }, { threshold: 0.15 });
  revealEls.forEach(el => io.observe(el));
} else {
  revealEls.forEach(el => el.classList.add('in'));
}

// Lead / contact form handling (static demo — wire to your CRM/email endpoint)
document.querySelectorAll('form[data-lead-form]').forEach(form => {
  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const success = form.parentElement.querySelector('.form-success') || document.querySelector('.form-success');
    if (success) {
      success.classList.add('show');
      success.textContent = "Thanks — your request has been received. Our team will reach out within one business day.";
    }
    form.reset();
    // Integration point:
    // Replace this block with a fetch() call to your backend / CRM webhook, e.g.
    // fetch('/api/lead', { method: 'POST', body: new FormData(form) })
  });
});

// Footer year
document.querySelectorAll('.year').forEach(el => el.textContent = new Date().getFullYear());
